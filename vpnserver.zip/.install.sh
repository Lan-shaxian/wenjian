#!/bin/sh

echo "--------------------------------------------------------------------"
echo
echo "SoftEther VPN Server (Ver 4.42, Build 9798, Intel x64 / AMD64) for Linux Build Utility"
echo "Copyright (c) SoftEther Project at University of Tsukuba, Japan. All Rights Reserved."
echo
echo "--------------------------------------------------------------------"
echo
echo

cat ReadMeFirst_License.txt

echo
echo "--------------------------------------------------------------------"
echo
echo

make main

exit 0

